import AppIntents

/// "Show agenda on Lock Screen" — use it in a Shortcuts automation (e.g. 07:00, 13:00, 19:00)
/// so the Live Activity is restarted before iOS's 8-hour limit.
struct ShowAgendaIntent: LiveActivityIntent {
    static let title: LocalizedStringResource = "Mostra agenda sul blocco schermo"

    @MainActor
    func perform() async throws -> some IntentResult {
        try await AgendaController.shared.show(forceRestart: true)
        return .result()
    }
}

struct HideAgendaIntent: LiveActivityIntent {
    static let title: LocalizedStringResource = "Nascondi agenda dal blocco schermo"

    @MainActor
    func perform() async throws -> some IntentResult {
        await AgendaController.shared.hide()
        return .result()
    }
}

struct AgendaShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(
            intent: ShowAgendaIntent(),
            phrases: [
                "Mostra agenda con \(.applicationName)",
                "Aggiorna \(.applicationName)"
            ],
            shortTitle: "Mostra agenda",
            systemImageName: "calendar"
        )
        AppShortcut(
            intent: HideAgendaIntent(),
            phrases: ["Nascondi agenda con \(.applicationName)"],
            shortTitle: "Nascondi agenda",
            systemImageName: "calendar.badge.minus"
        )
    }
}
