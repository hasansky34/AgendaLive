import AppIntents

/// "Show agenda on Lock Screen" — use it in a Shortcuts automation (e.g. 07:00, 13:00, 19:00)
/// so the Live Activity is restarted before iOS's 8-hour limit.
struct ShowAgendaIntent: LiveActivityIntent {
    static let title: LocalizedStringResource = "Mostra agenda sul blocco schermo"

    @MainActor
    func perform() async throws -> some IntentResult {
        try await AgendaController.shared.show(forceRestart: true)
        return .result()
    }
}

/// "Aggiorna agenda": quick refresh for frequent automations (every few minutes,
/// or when you leave Reminders/Fantastical). Restarts the card only when needed.
struct RefreshAgendaIntent: LiveActivityIntent {
    static let title: LocalizedStringResource = "Aggiorna agenda"

    @MainActor
    func perform() async throws -> some IntentResult {
        await AgendaController.shared.automaticRefresh()
        return .result()
    }
}

struct HideAgendaIntent: LiveActivityIntent {
    static let title: LocalizedStringResource = "Nascondi agenda dal blocco schermo"

    @MainActor
    func perform() async throws -> some IntentResult {
        await AgendaController.shared.hide()
        return .result()
    }
}

struct AgendaShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(
            intent: ShowAgendaIntent(),
            phrases: ["Mostra agenda con \(.applicationName)"],
            shortTitle: "Mostra agenda",
            systemImageName: "calendar"
        )
        AppShortcut(
            intent: RefreshAgendaIntent(),
            phrases: ["Aggiorna agenda con \(.applicationName)"],
            shortTitle: "Aggiorna agenda",
            systemImageName: "arrow.clockwise"
        )
        AppShortcut(
            intent: HideAgendaIntent(),
            phrases: ["Nascondi agenda con \(.applicationName)"],
            shortTitle: "Nascondi agenda",
            systemImageName: "calendar.badge.minus"
        )
    }
}
