import SwiftUI

@main
struct AgendaLiveApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(AgendaController.shared)
        }
        .backgroundTask(.appRefresh(AgendaConstants.refreshTaskID)) {
            // Background refresh can update the Live Activity but not start one.
            await AgendaController.shared.refresh()
        }
    }
}
