import EventKit
import Foundation
import UIKit

struct AgendaSnapshot {
    var state: AgendaAttributes.ContentState
    /// The next moment the list changes on its own (an item starts or ends).
    var nextChange: Date?
}

/// Reads today's and tomorrow's events and reminders and picks what fits on the card.
final class AgendaBuilder {
    private let store: EKEventStore

    init(store: EKEventStore) {
        self.store = store
    }

    func snapshot(
        maxRows: Int,
        maxRowsWithTomorrow: Int,
        includeOlderOverdue: Bool,
        hiddenCalendarIDs: Set<String>,
        now: Date = Date()
    ) async -> AgendaSnapshot {
        let calendar = Calendar.current
        let startToday = calendar.startOfDay(for: now)
        let startTomorrow = calendar.date(byAdding: .day, value: 1, to: startToday) ?? startToday.addingTimeInterval(86_400)
        let endTomorrow = calendar.date(byAdding: .day, value: 2, to: startToday) ?? startToday.addingTimeInterval(172_800)

        var today: [AgendaItem] = []
        var tomorrow: [AgendaItem] = []
        var changePoints: [Date] = [startTomorrow]

        // Calendar events, only from the calendars ticked in the app
        let eventCalendars = visibleCalendars(for: .event, hidden: hiddenCalendarIDs)
        if !eventCalendars.isEmpty {
            let predicate = store.predicateForEvents(withStart: startToday, end: endTomorrow, calendars: eventCalendars)
            let events = store.events(matching: predicate)
            for (index, event) in events.enumerated() {
                guard event.status != .canceled,
                      !Self.isDeclined(event),
                      let start = event.startDate,
                      let end = event.endDate else { continue }

                let item = AgendaItem(
                    id: "e\(index)",
                    title: Self.clean(event.title),
                    kind: .event,
                    start: start,
                    end: end,
                    isAllDay: event.isAllDay,
                    isOverdue: false,
                    colorHex: Self.hex(event.calendar?.cgColor)
                )

                if start < startTomorrow {
                    guard end > now else { continue } // already over
                    today.append(item)
                    if !event.isAllDay {
                        if start > now { changePoints.append(start) }
                        changePoints.append(end)
                    }
                } else {
                    tomorrow.append(item)
                }
            }
        }

        // Reminders, only from the lists ticked in the app
        let reminderLists = visibleCalendars(for: .reminder, hidden: hiddenCalendarIDs)
        if !reminderLists.isEmpty {
            let predicate = store.predicateForIncompleteReminders(
                withDueDateStarting: nil,
                ending: endTomorrow,
                calendars: reminderLists
            )
            for info in await fetchReminders(matching: predicate) {
                if info.due >= endTomorrow { continue }
                if info.due >= startTomorrow {
                    tomorrow.append(info.item(overdue: false))
                    continue
                }
                if calendar.startOfDay(for: info.due) < startToday {
                    if includeOlderOverdue {
                        today.append(info.item(overdue: true))
                    }
                    continue
                }
                let overdue = info.hasTime && info.due <= now
                today.append(info.item(overdue: overdue))
                if info.hasTime && info.due > now {
                    changePoints.append(info.due)
                }
            }
        }

        // Group today's items
        let byTime: (AgendaItem, AgendaItem) -> Bool = { $0.start < $1.start }
        let overdue = today.filter { $0.isOverdue }.sorted(by: byTime)
        let ongoing = today.filter { !$0.isOverdue && !$0.isAllDay && $0.start <= now }.sorted(by: byTime)
        let upcoming = today.filter { !$0.isOverdue && !$0.isAllDay && $0.start > now }.sorted(by: byTime)
        let allDay = today.filter { !$0.isOverdue && $0.isAllDay }.sorted {
            ($0.kind == .event ? 0 : 1, $0.title) < ($1.kind == .event ? 0 : 1, $1.title)
        }

        // Pick what fits, most useful first: a couple of overdue to-dos,
        // what's happening now, what's next, all-day items, then older overdue.
        let priority = Array(overdue.prefix(2)) + ongoing + upcoming + allDay + Array(overdue.dropFirst(2))
        let chosenIDs = Set(priority.prefix(maxRows).map(\.id))

        // Show them like Apple Calendar: all-day on top, then by time, with the
        // "now" line between what has started and what's coming.
        let shownAllDay = allDay.filter { chosenIDs.contains($0.id) }
        let shownPast = (overdue + ongoing).filter { chosenIDs.contains($0.id) }.sorted(by: byTime)
        let shownUpcoming = upcoming.filter { chosenIDs.contains($0.id) }
        let todayRows = shownAllDay + shownPast + shownUpcoming

        // Tomorrow only gets the rows today doesn't need. Its heading takes about
        // one row, so with tomorrow shown the card holds one row less.
        let room = todayRows.count >= maxRowsWithTomorrow
            ? 0
            : maxRowsWithTomorrow - max(todayRows.count, 1)
        let tomorrowRows = Array(tomorrow.sorted(by: Self.dayOrder).prefix(room))

        let state = AgendaAttributes.ContentState(
            day: startToday,
            today: todayRows,
            tomorrow: tomorrowRows,
            nowIndex: shownAllDay.count + shownPast.count,
            remainingToday: today.count,
            updatedAt: now
        )
        return AgendaSnapshot(state: state, nextChange: changePoints.filter { $0 > now }.min())
    }

    // MARK: - Reminders

    private struct ReminderInfo {
        var id: String
        var title: String
        var due: Date
        var hasTime: Bool
        var colorHex: String

        func item(overdue: Bool) -> AgendaItem {
            AgendaItem(
                id: id,
                title: title,
                kind: .reminder,
                start: due,
                end: nil,
                isAllDay: !hasTime,
                isOverdue: overdue,
                colorHex: colorHex
            )
        }
    }

    private func fetchReminders(matching predicate: NSPredicate) async -> [ReminderInfo] {
        await withCheckedContinuation { continuation in
            store.fetchReminders(matching: predicate) { reminders in
                let infos: [ReminderInfo] = (reminders ?? []).compactMap { reminder in
                    guard let components = reminder.dueDateComponents,
                          let due = Calendar.current.date(from: components) else { return nil }
                    return ReminderInfo(
                        id: reminder.calendarItemIdentifier,
                        title: AgendaBuilder.clean(reminder.title),
                        due: due,
                        hasTime: components.hour != nil,
                        colorHex: AgendaBuilder.hex(reminder.calendar?.cgColor)
                    )
                }
                continuation.resume(returning: infos)
            }
        }
    }

    // MARK: - Helpers

    /// Calendars (or reminder lists) the app may read, minus the ones switched off.
    private func visibleCalendars(for type: EKEntityType, hidden: Set<String>) -> [EKCalendar] {
        guard EKEventStore.authorizationStatus(for: type) == .fullAccess else { return [] }
        return store.calendars(for: type).filter { !hidden.contains($0.calendarIdentifier) }
    }

    private static func dayOrder(_ a: AgendaItem, _ b: AgendaItem) -> Bool {
        if a.isAllDay != b.isAllDay { return a.isAllDay }
        return a.start < b.start
    }

    private static func isDeclined(_ event: EKEvent) -> Bool {
        event.attendees?.first(where: { $0.isCurrentUser })?.participantStatus == .declined
    }

    static func clean(_ title: String?) -> String {
        let trimmed = (title ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? "Senza titolo" : String(trimmed.prefix(60))
    }

    static func hex(_ color: CGColor?) -> String {
        guard let color else { return "8E8E93" }
        let uiColor = UIColor(cgColor: color)
        var red: CGFloat = 0, green: CGFloat = 0, blue: CGFloat = 0, alpha: CGFloat = 0
        guard uiColor.getRed(&red, green: &green, blue: &blue, alpha: &alpha) else { return "8E8E93" }
        func byte(_ value: CGFloat) -> Int { Int((min(max(value, 0), 1) * 255).rounded()) }
        return String(format: "%02X%02X%02X", byte(red), byte(green), byte(blue))
    }
}
