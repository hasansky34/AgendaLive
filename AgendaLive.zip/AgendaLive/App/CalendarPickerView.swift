import SwiftUI

/// Choose which calendars and reminder lists appear on the Lock Screen,
/// laid out like the Calendar app's "Calendari" screen.
struct CalendarPickerView: View {
    @EnvironmentObject private var controller: AgendaController

    var body: some View {
        List {
            let groups = controller.eventCalendarGroups()
            ForEach(groups) { group in
                Section {
                    ForEach(group.calendars) { calendar in
                        row(calendar)
                    }
                } header: {
                    Text(group.title)
                }
            }

            let lists = controller.reminderListChoices()
            if !lists.isEmpty {
                Section {
                    ForEach(lists) { list in
                        row(list)
                    }
                } header: {
                    Text("Promemoria")
                }
            }

            if groups.isEmpty && lists.isEmpty {
                Text("Consenti l'accesso a Calendario e Promemoria per scegliere i calendari.")
                    .foregroundStyle(.secondary)
            }
        }
        .navigationTitle("Calendari")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .bottomBar) {
                Button("Nascondi tutti") {
                    controller.setAllCalendars(shown: false)
                }
                Spacer()
                Button("Mostra tutti") {
                    controller.setAllCalendars(shown: true)
                }
            }
        }
    }

    private func row(_ calendar: AgendaController.CalendarChoice) -> some View {
        let shown = controller.isShown(calendar.id)
        let color = Color(hex: calendar.colorHex)
        return Button {
            controller.toggleCalendar(calendar.id)
        } label: {
            HStack(spacing: 14) {
                ZStack {
                    Circle()
                        .strokeBorder(color, lineWidth: 2)
                    if shown {
                        Circle()
                            .fill(color)
                        Image(systemName: "checkmark")
                            .font(.system(size: 11, weight: .bold))
                            .foregroundStyle(.white)
                    }
                }
                .frame(width: 22, height: 22)

                Text(calendar.title)
                    .foregroundStyle(.primary)
                Spacer()
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(shown ? .isSelected : [])
    }
}
