import SwiftUI
import UIKit

struct ContentView: View {
    @EnvironmentObject private var controller: AgendaController
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.openURL) private var openURL

    var body: some View {
        NavigationStack {
            List {
                Section {
                    AgendaCardView(state: controller.state)
                        .environment(\.colorScheme, previewScheme)
                        .padding(.horizontal, AgendaStyle.horizontalPadding)
                        .padding(.vertical, AgendaStyle.verticalPadding)
                        .background(AgendaPalette.of(previewScheme).background, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
                        .listRowInsets(EdgeInsets(top: 8, leading: 0, bottom: 8, trailing: 0))
                        .listRowBackground(Color.clear)
                } header: {
                    Text("Anteprima")
                } footer: {
                    Text(statusText)
                }

                if !controller.eventsAccess || !controller.remindersAccess {
                    Section {
                        Button("Consenti accesso a Calendario e Promemoria") {
                            Task {
                                await controller.requestAccess()
                                await controller.refresh()
                            }
                        }
                        Button("Apri Impostazioni") {
                            if let url = URL(string: UIApplication.openSettingsURLString) {
                                openURL(url)
                            }
                        }
                    } footer: {
                        Text("Serve l'accesso completo per leggere eventi e promemoria. Se l'hai negato, attivalo in Impostazioni › Agenda.")
                    }
                }

                Section {
                    Button {
                        Task { await controller.userShow() }
                    } label: {
                        Label("Mostra sul blocco schermo", systemImage: "lock.rectangle.on.rectangle")
                    }
                    Button {
                        Task { await controller.refresh() }
                    } label: {
                        Label("Aggiorna ora", systemImage: "arrow.clockwise")
                    }
                    Button(role: .destructive) {
                        Task { await controller.hide() }
                    } label: {
                        Label("Nascondi dal blocco schermo", systemImage: "eye.slash")
                    }
                }

                Section {
                    NavigationLink {
                        CalendarPickerView()
                            .environmentObject(controller)
                    } label: {
                        HStack {
                            Label("Calendari", systemImage: "calendar")
                            Spacer()
                            Text(controller.calendarSummary)
                                .foregroundStyle(.secondary)
                        }
                    }
                    Picker(selection: $controller.appearanceMode) {
                        ForEach(AppearanceMode.allCases) { mode in
                            Text(mode.label).tag(mode)
                        }
                    } label: {
                        Label("Aspetto", systemImage: "circle.lefthalf.filled")
                    }
                    Toggle("Promemoria scaduti dei giorni prima", isOn: $controller.includeOlderOverdue)
                } header: {
                    Text("Opzioni")
                } footer: {
                    Text("Aspetto Automatico segue la modalità chiara/scura dell'iPhone e cambia al prossimo aggiornamento della card. I promemoria scaduti oggi compaiono sempre, in rosso.")
                }

                Section {
                    Toggle("Aggiornamento automatico", isOn: $controller.autoRefresh)
                    if controller.autoRefresh {
                        Picker("Ogni", selection: $controller.tickMinutes) {
                            ForEach(AgendaConstants.tickChoices, id: \.self) { minutes in
                                Text("\(minutes) minuti").tag(minutes)
                            }
                        }
                        Toggle("Notifiche silenziose", isOn: $controller.quietTicks)
                        VStack(alignment: .leading, spacing: 10) {
                            step(1, "Apri Comandi e crea un nuovo comando con l'azione «Aggiorna agenda» (app Agenda).")
                            step(2, "Aggiungi l'automazione «Quando ricevo una notifica» e scegli l'app Agenda.")
                            step(3, "Fallo eseguire senza chiedere conferma, anche con iPhone bloccato.")
                        }
                        .padding(.vertical, 4)
                    }
                } header: {
                    Text("Tienila sempre aggiornata")
                } footer: {
                    Text("Agenda si manda una notifica silenziosa ogni pochi minuti e l'automazione aggiorna la card, riavviandola prima del limite di 8 ore di iOS. Se la card non si aggiorna, disattiva «Notifiche silenziose».")
                }
            }
            .navigationTitle("Agenda")
            .alert(
                "Agenda",
                isPresented: Binding(
                    get: { controller.message != nil },
                    set: { if !$0 { controller.message = nil } }
                )
            ) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(controller.message ?? "")
            }
        }
        .onChange(of: scenePhase, initial: true) { _, phase in
            if phase == .active {
                Task { await controller.appBecameActive() }
            }
        }
        .onChange(of: colorScheme) { _, _ in
            // The phone switched light/dark while the app is open.
            Task { await controller.refresh() }
        }
    }

    /// The look the Lock Screen card will have.
    private var previewScheme: ColorScheme {
        guard let dark = controller.state.dark else { return colorScheme }
        return dark ? .dark : .light
    }

    private var statusText: String {
        if controller.isShowing {
            let time = controller.state.updatedAt.formatted(date: .omitted, time: .shortened)
            return "Sul blocco schermo · aggiornata alle \(time)"
        }
        return "Non è sul blocco schermo."
    }

    private func step(_ number: Int, _ text: String) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 10) {
            Text("\(number)")
                .font(.footnote.weight(.semibold))
                .foregroundStyle(.white)
                .frame(width: 20, height: 20)
                .background(Circle().fill(Color.red))
            Text(text)
                .font(.subheadline)
        }
    }
}
