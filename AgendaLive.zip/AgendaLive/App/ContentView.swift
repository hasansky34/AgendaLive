import SwiftUI
import UIKit

struct ContentView: View {
    @EnvironmentObject private var controller: AgendaController
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.openURL) private var openURL

    var body: some View {
        NavigationStack {
            List {
                Section {
                    AgendaCardView(state: controller.state)
                        .padding(.horizontal, AgendaStyle.horizontalPadding)
                        .padding(.vertical, AgendaStyle.verticalPadding)
                        .background(AgendaPalette.of(colorScheme).background, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
                        .listRowInsets(EdgeInsets(top: 8, leading: 0, bottom: 8, trailing: 0))
                        .listRowBackground(Color.clear)
                } header: {
                    Text("Anteprima")
                } footer: {
                    Text(statusText)
                }

                if !controller.eventsAccess || !controller.remindersAccess {
                    Section {
                        Button("Consenti accesso a Calendario e Promemoria") {
                            Task {
                                await controller.requestAccess()
                                await controller.refresh()
                            }
                        }
                        Button("Apri Impostazioni") {
                            if let url = URL(string: UIApplication.openSettingsURLString) {
                                openURL(url)
                            }
                        }
                    } footer: {
                        Text("Serve l'accesso completo per leggere eventi e promemoria. Se l'hai negato, attivalo in Impostazioni › Agenda.")
                    }
                }

                Section {
                    Button {
                        Task { await controller.userShow() }
                    } label: {
                        Label("Mostra sul blocco schermo", systemImage: "lock.rectangle.on.rectangle")
                    }
                    Button {
                        Task { await controller.refresh() }
                    } label: {
                        Label("Aggiorna ora", systemImage: "arrow.clockwise")
                    }
                    Button(role: .destructive) {
                        Task { await controller.hide() }
                    } label: {
                        Label("Nascondi dal blocco schermo", systemImage: "eye.slash")
                    }
                }

                Section {
                    NavigationLink {
                        CalendarPickerView()
                            .environmentObject(controller)
                    } label: {
                        HStack {
                            Label("Calendari", systemImage: "calendar")
                            Spacer()
                            Text(controller.calendarSummary)
                                .foregroundStyle(.secondary)
                        }
                    }
                    Toggle("Promemoria scaduti dei giorni prima", isOn: $controller.includeOlderOverdue)
                } header: {
                    Text("Opzioni")
                } footer: {
                    Text("Scegli quali calendari e liste di promemoria mostrare. I promemoria scaduti oggi compaiono sempre, in rosso.")
                }

                Section {
                    VStack(alignment: .leading, spacing: 10) {
                        step(1, "Apri Comandi › Automazione › +.")
                        step(2, "Scegli «Ora del giorno», imposta 07:00, Ogni giorno, «Esegui immediatamente».")
                        step(3, "Aggiungi l'azione «Mostra agenda sul blocco schermo» (app Agenda).")
                        step(4, "Ripeti per le 13:00 e le 19:00.")
                    }
                    .padding(.vertical, 4)
                } header: {
                    Text("Tienila sempre attiva")
                } footer: {
                    Text("iOS chiude le attività in tempo reale dopo 8 ore. Queste automazioni la riavviano e la aggiornano durante il giorno.")
                }
            }
            .navigationTitle("Agenda")
            .alert(
                "Agenda",
                isPresented: Binding(
                    get: { controller.message != nil },
                    set: { if !$0 { controller.message = nil } }
                )
            ) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(controller.message ?? "")
            }
        }
        .onChange(of: scenePhase, initial: true) { _, phase in
            if phase == .active {
                Task { await controller.appBecameActive() }
            }
        }
    }

    private var statusText: String {
        if controller.isShowing {
            let time = controller.state.updatedAt.formatted(date: .omitted, time: .shortened)
            return "Sul blocco schermo · aggiornata alle \(time)"
        }
        return "Non è sul blocco schermo."
    }

    private func step(_ number: Int, _ text: String) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 10) {
            Text("\(number)")
                .font(.footnote.weight(.semibold))
                .foregroundStyle(.white)
                .frame(width: 20, height: 20)
                .background(Circle().fill(Color.red))
            Text(text)
                .font(.subheadline)
        }
    }
}
