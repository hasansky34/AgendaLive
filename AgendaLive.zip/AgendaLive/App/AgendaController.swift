import ActivityKit
import BackgroundTasks
import EventKit
import Foundation
import UIKit
import UserNotifications

/// Light/dark setting for the Lock Screen card.
enum AppearanceMode: String, CaseIterable, Identifiable {
    case automatic
    case light
    case dark

    var id: String { rawValue }

    var label: String {
        switch self {
        case .automatic: return "Automatico"
        case .light: return "Chiaro"
        case .dark: return "Scuro"
        }
    }
}

enum AgendaConstants {
    static let refreshTaskID = "agendalive.refresh"
    /// The repeating quiet notification that starts the "Aggiorna agenda" automation.
    static let tickID = "agenda-tick"
    static let tickChoices = [5, 10, 15, 30]
    /// When opened or tapped, restart the Live Activity if it's older than this,
    /// so it doesn't hit the 8-hour limit.
    static let restartAfter: TimeInterval = 3 * 60 * 60
}

enum AgendaError: LocalizedError {
    case liveActivitiesDisabled

    var errorDescription: String? {
        switch self {
        case .liveActivitiesDisabled:
            return "Le attività in tempo reale sono disattivate per Agenda. Attivale in Impostazioni › Agenda › Attività in tempo reale."
        }
    }
}

/// Reads the agenda and keeps the Live Activity in sync.
@MainActor
final class AgendaController: ObservableObject {
    static let shared = AgendaController()

    @Published private(set) var state: AgendaAttributes.ContentState = .empty
    @Published private(set) var eventsAccess = false
    @Published private(set) var remindersAccess = false
    @Published private(set) var isShowing = false
    @Published var message: String?

    @Published var appearanceMode: AppearanceMode {
        didSet {
            UserDefaults.standard.set(appearanceMode.rawValue, forKey: Keys.appearance)
            Task { await refresh() }
        }
    }

    /// Send a quiet notification every few minutes so a Shortcuts automation
    /// ("When I receive a notification from Agenda") can run "Aggiorna agenda".
    @Published var autoRefresh: Bool {
        didSet {
            UserDefaults.standard.set(autoRefresh, forKey: Keys.autoRefresh)
            Task { await updateTicks(reset: true, askPermission: true, reportDenied: true) }
        }
    }

    @Published var tickMinutes: Int {
        didSet {
            UserDefaults.standard.set(tickMinutes, forKey: Keys.tickMinutes)
            Task { await updateTicks(reset: true) }
        }
    }

    /// Quiet = no sound, no banner, straight to Notification Center.
    @Published var quietTicks: Bool {
        didSet {
            UserDefaults.standard.set(quietTicks, forKey: Keys.quietTicks)
            Task { await updateTicks(reset: true) }
        }
    }

    @Published var includeOlderOverdue: Bool {
        didSet {
            UserDefaults.standard.set(includeOlderOverdue, forKey: Keys.includeOlderOverdue)
            Task { await refresh() }
        }
    }

    /// Calendars and reminder lists switched off in the app. Stored as "hidden" so
    /// new calendars show up automatically, like in the Calendar app.
    @Published private(set) var hiddenCalendarIDs: Set<String>

    /// Whether the person wants the agenda on the Lock Screen.
    private(set) var isEnabled: Bool {
        get { UserDefaults.standard.object(forKey: Keys.enabled) as? Bool ?? true }
        set { UserDefaults.standard.set(newValue, forKey: Keys.enabled) }
    }

    private enum Keys {
        static let enabled = "agendaEnabled"
        static let includeOlderOverdue = "includeOlderOverdue"
        static let appearance = "appearanceMode"
        static let autoRefresh = "autoRefresh"
        static let tickMinutes = "tickMinutes"
        static let quietTicks = "quietTicks"
        static let hiddenCalendars = "hiddenCalendarIDs"
    }

    let store: EKEventStore
    private let builder: AgendaBuilder
    private var storeObserver: NSObjectProtocol?
    private var pendingRefresh: Task<Void, Never>?

    private init() {
        let store = EKEventStore()
        self.store = store
        self.builder = AgendaBuilder(store: store)
        self.includeOlderOverdue = UserDefaults.standard.bool(forKey: Keys.includeOlderOverdue)
        self.appearanceMode = AppearanceMode(
            rawValue: UserDefaults.standard.string(forKey: Keys.appearance) ?? ""
        ) ?? .automatic
        self.autoRefresh = UserDefaults.standard.object(forKey: Keys.autoRefresh) as? Bool ?? true
        self.tickMinutes = UserDefaults.standard.object(forKey: Keys.tickMinutes) as? Int ?? 5
        self.quietTicks = UserDefaults.standard.object(forKey: Keys.quietTicks) as? Bool ?? true
        self.hiddenCalendarIDs = Set(UserDefaults.standard.stringArray(forKey: Keys.hiddenCalendars) ?? [])
        updateAccess()

        // Calendar or Reminders changed while the app is running.
        storeObserver = NotificationCenter.default.addObserver(
            forName: .EKEventStoreChanged,
            object: store,
            queue: .main
        ) { _ in
            Task { @MainActor in
                AgendaController.shared.scheduleRefresh()
            }
        }
    }

    // MARK: - Permissions

    var needsAccessPrompt: Bool {
        EKEventStore.authorizationStatus(for: .event) == .notDetermined
            || EKEventStore.authorizationStatus(for: .reminder) == .notDetermined
    }

    func updateAccess() {
        eventsAccess = EKEventStore.authorizationStatus(for: .event) == .fullAccess
        remindersAccess = EKEventStore.authorizationStatus(for: .reminder) == .fullAccess
    }

    func requestAccess() async {
        if EKEventStore.authorizationStatus(for: .event) == .notDetermined {
            _ = try? await store.requestFullAccessToEvents()
        }
        if EKEventStore.authorizationStatus(for: .reminder) == .notDetermined {
            _ = try? await store.requestFullAccessToReminders()
        }
        updateAccess()
    }

    // MARK: - Entry points

    /// The app came to the foreground.
    func appBecameActive() async {
        if needsAccessPrompt {
            await requestAccess()
        }
        updateAccess()
        if isEnabled {
            do {
                try await show(forceRestart: false)
            } catch {
                message = error.localizedDescription
                await refresh()
            }
        } else {
            await refresh()
        }
        clearDeliveredTicks()
        await updateTicks(askPermission: true)
    }

    /// "Aggiorna agenda", run by the Shortcuts automation every few minutes:
    /// refreshes the card, restarts it before iOS's 8-hour limit, keeps the ticks going.
    func automaticRefresh() async {
        clearDeliveredTicks()
        if isEnabled {
            do {
                try await show(forceRestart: false)
            } catch {
                await refresh()
            }
        } else {
            await refresh()
        }
        await updateTicks()
    }

    /// "Show on Lock Screen" button in the app.
    func userShow() async {
        do {
            try await show(forceRestart: true)
        } catch {
            message = error.localizedDescription
        }
    }

    /// A reminder's circle was tapped on the Lock Screen (or in the app).
    func complete(reminderID: String) async {
        if let reminder = store.calendarItem(withIdentifier: reminderID) as? EKReminder {
            reminder.isCompleted = true
            do {
                try store.save(reminder, commit: true)
            } catch {
                message = error.localizedDescription
            }
        }
        // This runs inside a LiveActivityIntent, so restarting an old activity is allowed here.
        if isEnabled {
            do {
                try await show(forceRestart: false)
                return
            } catch {
                // Fall through to a plain update.
            }
        }
        await refresh()
    }

    // MARK: - Live Activity

    /// Starts the Live Activity, or updates the running one.
    /// Starting only works from the foreground app or from a LiveActivityIntent.
    func show(forceRestart: Bool) async throws {
        isEnabled = true
        let snapshot = await makeSnapshot()
        apply(snapshot)

        let running = runningActivities()
        if let current = running.first, !forceRestart,
           Date().timeIntervalSince(current.attributes.startedAt) < AgendaConstants.restartAfter {
            await current.update(content(for: snapshot))
            for extra in running.dropFirst() {
                await extra.end(nil, dismissalPolicy: .immediate)
            }
            isShowing = true
            return
        }

        guard ActivityAuthorizationInfo().areActivitiesEnabled else {
            isShowing = !running.isEmpty
            throw AgendaError.liveActivitiesDisabled
        }

        for activity in Activity<AgendaAttributes>.activities {
            await activity.end(nil, dismissalPolicy: .immediate)
        }
        _ = try Activity<AgendaAttributes>.request(
            attributes: AgendaAttributes(startedAt: Date()),
            content: content(for: snapshot),
            pushType: nil
        )
        isShowing = true
    }

    /// Rebuilds the agenda and updates the running Live Activity. Never starts a new one,
    /// so it's safe from background refresh.
    func refresh() async {
        updateAccess()
        let snapshot = await makeSnapshot()
        apply(snapshot)
        let running = runningActivities()
        for activity in running {
            await activity.update(content(for: snapshot))
        }
        isShowing = !running.isEmpty
    }

    func hide() async {
        isEnabled = false
        for activity in Activity<AgendaAttributes>.activities {
            await activity.end(nil, dismissalPolicy: .immediate)
        }
        isShowing = false
    }

    // MARK: - Automatic updates

    /// Schedules, or removes, the repeating quiet notification.
    /// Adding it again with the same identifier replaces the old one.
    func updateTicks(reset: Bool = false, askPermission: Bool = false, reportDenied: Bool = false) async {
        let center = UNUserNotificationCenter.current()
        guard autoRefresh else {
            center.removePendingNotificationRequests(withIdentifiers: [AgendaConstants.tickID])
            clearDeliveredTicks()
            return
        }

        var settings = await center.notificationSettings()
        if settings.authorizationStatus == .notDetermined && askPermission {
            _ = try? await center.requestAuthorization(options: [.alert])
            settings = await center.notificationSettings()
        }
        guard settings.authorizationStatus == .authorized
                || settings.authorizationStatus == .provisional else {
            if reportDenied {
                message = "Per l'aggiornamento automatico attiva le notifiche: Impostazioni › Notifiche › Agenda."
            }
            return
        }

        if !reset {
            let pending = await center.pendingNotificationRequests()
            if pending.contains(where: { $0.identifier == AgendaConstants.tickID }) {
                return // already ticking, keep the rhythm
            }
        }

        let content = UNMutableNotificationContent()
        content.title = "Agenda"
        content.body = "Aggiornamento automatico"
        content.threadIdentifier = AgendaConstants.tickID
        content.interruptionLevel = quietTicks ? .passive : .active

        let trigger = UNTimeIntervalNotificationTrigger(
            timeInterval: TimeInterval(max(tickMinutes, 1) * 60),
            repeats: true
        )
        let request = UNNotificationRequest(identifier: AgendaConstants.tickID, content: content, trigger: trigger)
        try? await center.add(request)
    }

    private func clearDeliveredTicks() {
        UNUserNotificationCenter.current().removeDeliveredNotifications(withIdentifiers: [AgendaConstants.tickID])
    }

    // MARK: - Calendar selection

    struct CalendarChoice: Identifiable {
        let id: String
        let title: String
        let colorHex: String
    }

    struct CalendarGroup: Identifiable {
        let id: String
        let title: String
        let calendars: [CalendarChoice]
    }

    func isShown(_ calendarID: String) -> Bool {
        !hiddenCalendarIDs.contains(calendarID)
    }

    func toggleCalendar(_ calendarID: String) {
        if hiddenCalendarIDs.contains(calendarID) {
            hiddenCalendarIDs.remove(calendarID)
        } else {
            hiddenCalendarIDs.insert(calendarID)
        }
        saveHiddenCalendars()
    }

    func setAllCalendars(shown: Bool) {
        hiddenCalendarIDs = shown ? [] : Set(allCalendars().map { $0.calendarIdentifier })
        saveHiddenCalendars()
    }

    /// "Tutti" or e.g. "5 di 8".
    var calendarSummary: String {
        let all = allCalendars()
        let shown = all.filter { !hiddenCalendarIDs.contains($0.calendarIdentifier) }.count
        return shown == all.count ? "Tutti" : "\(shown) di \(all.count)"
    }

    /// Event calendars grouped by account, in the Calendar app's order.
    func eventCalendarGroups() -> [CalendarGroup] {
        let grouped = Dictionary(grouping: calendars(for: .event)) { calendar in
            calendar.source?.sourceIdentifier ?? "other"
        }
        var groups: [(rank: Int, group: CalendarGroup)] = []
        for (key, calendars) in grouped {
            let (rank, title) = Self.describe(calendars.first?.source)
            let choices = calendars
                .sorted { $0.title.localizedStandardCompare($1.title) == .orderedAscending }
                .map { Self.choice($0) }
            groups.append((rank: rank, group: CalendarGroup(id: key, title: title, calendars: choices)))
        }
        return groups
            .sorted { ($0.rank, $0.group.title) < ($1.rank, $1.group.title) }
            .map { $0.group }
    }

    /// Reminder lists, alphabetically.
    func reminderListChoices() -> [CalendarChoice] {
        calendars(for: .reminder)
            .sorted { $0.title.localizedStandardCompare($1.title) == .orderedAscending }
            .map { Self.choice($0) }
    }

    private func saveHiddenCalendars() {
        UserDefaults.standard.set(Array(hiddenCalendarIDs), forKey: Keys.hiddenCalendars)
        scheduleRefresh()
    }

    private func allCalendars() -> [EKCalendar] {
        calendars(for: .event) + calendars(for: .reminder)
    }

    private func calendars(for type: EKEntityType) -> [EKCalendar] {
        guard EKEventStore.authorizationStatus(for: type) == .fullAccess else { return [] }
        return store.calendars(for: type)
    }

    private static func choice(_ calendar: EKCalendar) -> CalendarChoice {
        CalendarChoice(
            id: calendar.calendarIdentifier,
            title: calendar.title,
            colorHex: AgendaBuilder.hex(calendar.cgColor)
        )
    }

    /// Section order and name for an account, like the Calendar app.
    private static func describe(_ source: EKSource?) -> (Int, String) {
        guard let source else { return (5, "Altro") }
        switch source.sourceType {
        case .mobileMe: return (0, source.title)
        case .calDAV, .exchange: return (1, source.title)
        case .local: return (2, "Sul mio iPhone")
        case .subscribed: return (3, "Iscrizioni")
        case .birthdays: return (4, "Altro")
        @unknown default: return (5, source.title)
        }
    }

    // MARK: - Helpers

    private func scheduleRefresh() {
        pendingRefresh?.cancel()
        pendingRefresh = Task {
            try? await Task.sleep(nanoseconds: 500_000_000)
            guard !Task.isCancelled else { return }
            await refresh()
        }
    }

    private func makeSnapshot() async -> AgendaSnapshot {
        var snapshot = await builder.snapshot(
            maxRows: AgendaStyle.maxRows,
            maxRowsWithTomorrow: AgendaStyle.maxRowsWithTomorrow,
            includeOlderOverdue: includeOlderOverdue,
            hiddenCalendarIDs: hiddenCalendarIDs
        )
        snapshot.state.dark = resolvedDark()
        snapshot.state.nextChange = snapshot.nextChange
        return snapshot
    }

    /// Light or dark for the card, from the setting or the phone's appearance.
    private func resolvedDark() -> Bool {
        switch appearanceMode {
        case .light: return false
        case .dark: return true
        case .automatic: return Self.phoneIsDark()
        }
    }

    private static func phoneIsDark() -> Bool {
        let scene = UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first
        let style = scene?.traitCollection.userInterfaceStyle
            ?? UIScreen.main.traitCollection.userInterfaceStyle
        return style == .dark
    }

    private func apply(_ snapshot: AgendaSnapshot) {
        state = snapshot.state
        scheduleBackgroundRefresh(after: snapshot.nextChange)
    }

    private func content(for snapshot: AgendaSnapshot) -> ActivityContent<AgendaAttributes.ContentState> {
        // At the stale date iOS redraws the card, which then applies the change itself.
        ActivityContent(state: snapshot.state, staleDate: snapshot.nextChange)
    }

    private func runningActivities() -> [Activity<AgendaAttributes>] {
        Activity<AgendaAttributes>.activities.filter {
            $0.activityState == .active || $0.activityState == .stale
        }
    }

    /// Asks iOS to wake the app around the next change (or within 30 minutes).
    /// iOS decides the exact time.
    private func scheduleBackgroundRefresh(after nextChange: Date?) {
        let now = Date()
        var earliest = now.addingTimeInterval(30 * 60)
        if let nextChange, nextChange > now {
            earliest = min(earliest, nextChange.addingTimeInterval(30))
        }
        let request = BGAppRefreshTaskRequest(identifier: AgendaConstants.refreshTaskID)
        request.earliestBeginDate = max(earliest, now.addingTimeInterval(5 * 60))
        try? BGTaskScheduler.shared.submit(request)
    }
}
