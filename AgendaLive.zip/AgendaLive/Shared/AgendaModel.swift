import ActivityKit
import Foundation

/// One row in the agenda: a calendar event or a reminder.
struct AgendaItem: Codable, Hashable, Identifiable {
    enum Kind: String, Codable, Hashable {
        case event
        case reminder
    }

    /// For reminders this is the EventKit identifier, used to tick them off.
    var id: String
    var title: String
    var kind: Kind
    /// Start time for events, due date for reminders.
    var start: Date
    var end: Date?
    var isAllDay: Bool
    var isOverdue: Bool
    /// Calendar or reminder-list color, e.g. "FF9F0A".
    var colorHex: String
}

/// The Live Activity shown on the Lock Screen.
struct AgendaAttributes: ActivityAttributes {
    struct ContentState: Codable, Hashable {
        /// Midnight of the day this agenda describes.
        var day: Date
        /// Today's rows in display order (all-day, past/ongoing, then upcoming).
        var today: [AgendaItem]
        /// A few of tomorrow's items, only when today leaves room.
        var tomorrow: [AgendaItem]
        /// Where the red "now" line sits inside `today` (0...today.count).
        var nowIndex: Int
        /// Everything still open today, including rows that didn't fit.
        var remainingToday: Int
        var updatedAt: Date
        /// Light or dark, decided by the app. iOS 26/27 don't reliably tell
        /// Live Activities the phone's appearance, so the app sends it along.
        /// Nil means "use what iOS says".
        var dark: Bool? = nil
        /// The next moment the list changes (a task falls due, an event starts or
        /// ends). iOS redraws the card at that moment, even if the app isn't running.
        var nextChange: Date? = nil
    }

    /// When this Live Activity was started. iOS stops it after 8 hours.
    var startedAt: Date
}

extension AgendaAttributes.ContentState {
    static var empty: AgendaAttributes.ContentState {
        AgendaAttributes.ContentState(
            day: Calendar.current.startOfDay(for: Date()),
            today: [],
            tomorrow: [],
            nowIndex: 0,
            remainingToday: 0,
            updatedAt: Date()
        )
    }

    /// The first upcoming item today, if any.
    var nextItem: AgendaItem? {
        today.indices.contains(nowIndex) ? today[nowIndex] : nil
    }

    /// Rows for the expanded Dynamic Island: upcoming first.
    var islandRows: [AgendaItem] {
        let upcoming = Array(today.dropFirst(nowIndex))
        return Array((upcoming.isEmpty ? today : upcoming).prefix(4))
    }

    /// What the card looks like once `nextChange` has passed, so it changes on time
    /// without waiting for the app: tasks due by then turn red, events that have
    /// ended disappear, and the "now" line moves down.
    func applyingStaleness(_ isStale: Bool) -> AgendaAttributes.ContentState {
        guard isStale, let moment = nextChange else { return self }
        var copy = self
        var rows: [AgendaItem] = []
        var newNowIndex = 0
        for (index, original) in today.enumerated() {
            var item = original
            if item.kind == .event, !item.isAllDay, let end = item.end, end <= moment {
                continue // over
            }
            if item.kind == .reminder, !item.isAllDay, item.start <= moment {
                item.isOverdue = true
            }
            rows.append(item)
            if index < nowIndex || (!item.isAllDay && item.start <= moment) {
                newNowIndex = rows.count
            }
        }
        copy.today = rows
        copy.nowIndex = newNowIndex
        copy.nextChange = nil
        return copy
    }

    var remainingLabel: String {
        switch remainingToday {
        case 0: return "tutto fatto"
        case 1: return "1 rimasto"
        default: return "\(remainingToday) rimasti"
        }
    }
}
