import SwiftUI

/// Colors and sizes in the style of Apple Calendar (dark).
///
/// iOS caps a Live Activity on the Lock Screen at 160 pt tall (iOS 27 too), so every
/// height here is fixed and adds up to at most 156 pt:
///   8 + 20 + 3 + 7 + 5 × 22 + 8 = 156   (5 rows of today)
///   8 + 20 + 3 + 7 + 18 + 4 × 22 + 8 = 152   (today + tomorrow, 4 rows in total)
enum AgendaStyle {
    /// Most rows when only today is shown.
    static let maxRows = 5
    /// Most rows (today + tomorrow) when the "Domani" heading is shown.
    static let maxRowsWithTomorrow = 4

    static let verticalPadding: CGFloat = 8
    static let horizontalPadding: CGFloat = 14
    static let headerHeight: CGFloat = 20
    static let headerGap: CGFloat = 3
    static let rowHeight: CGFloat = 22
    static let nowLineHeight: CGFloat = 7
    static let tomorrowHeaderHeight: CGFloat = 16
    static let tomorrowHeaderGap: CGFloat = 2

    static let timeWidth: CGFloat = 42
    static let markerWidth: CGFloat = 18
    static let spacing: CGFloat = 6

    static let titleFont = Font.system(size: 15)
    static let timeFont = Font.system(size: 13).monospacedDigit()
}

/// Apple's system colors for light and dark mode. Views pick one from the
/// environment's color scheme, so the card follows the phone's appearance.
struct AgendaPalette {
    let text: Color
    let secondary: Color
    let red: Color
    let separator: Color
    let background: Color

    static let dark = AgendaPalette(
        text: .white,
        secondary: Color(hex: "8E8E93"),
        red: Color(hex: "FF453A"),
        separator: Color(hex: "38383A"),
        background: .black
    )

    static let light = AgendaPalette(
        text: .black,
        secondary: Color(hex: "8A8A8E"),
        red: Color(hex: "FF3B30"),
        separator: Color(hex: "C6C6C8"),
        background: .white
    )

    static func of(_ scheme: ColorScheme) -> AgendaPalette {
        scheme == .dark ? .dark : .light
    }
}

extension Color {
    /// Creates a color from a hex string like "FF453A".
    init(hex: String) {
        let cleaned = hex.trimmingCharacters(in: CharacterSet(charactersIn: "# "))
        let value = UInt64(cleaned, radix: 16) ?? 0x8E8E93
        self.init(
            red: Double((value >> 16) & 0xFF) / 255,
            green: Double((value >> 8) & 0xFF) / 255,
            blue: Double(value & 0xFF) / 255
        )
    }
}

/// The agenda card. Used by the Live Activity and by the preview in the app.
struct AgendaCardView: View {
    let state: AgendaAttributes.ContentState
    @Environment(\.colorScheme) var colorScheme
    private var palette: AgendaPalette { .of(colorScheme) }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            header
                .padding(.bottom, AgendaStyle.headerGap)

            if state.today.isEmpty {
                Text(state.tomorrow.isEmpty ? "Nessun altro impegno oggi" : "Niente più per oggi")
                    .font(.system(size: 14))
                    .foregroundStyle(palette.secondary)
                    .frame(height: AgendaStyle.rowHeight)
            } else {
                ForEach(Array(state.today.enumerated()), id: \.element.id) { index, item in
                    if index == state.nowIndex {
                        NowLine()
                    }
                    AgendaRow(item: item, day: state.day)
                }
                if state.nowIndex >= state.today.count {
                    NowLine()
                }
            }

            if !state.tomorrow.isEmpty {
                tomorrowHeader
                ForEach(state.tomorrow) { item in
                    AgendaRow(item: item, day: tomorrowDate)
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var header: some View {
        HStack(alignment: .firstTextBaseline, spacing: 6) {
            Text("Oggi")
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(palette.red)
            Text(state.day, format: .dateTime.weekday(.abbreviated).day().month(.abbreviated))
                .font(.system(size: 15, weight: .medium))
                .foregroundStyle(palette.text)
            Spacer(minLength: 4)
            Text(state.remainingLabel)
                .font(.system(size: 13))
                .foregroundStyle(palette.secondary)
        }
        .frame(height: AgendaStyle.headerHeight)
    }

    private var tomorrowHeader: some View {
        HStack(spacing: 6) {
            Text("DOMANI")
                .font(.system(size: 11, weight: .semibold))
                .foregroundStyle(palette.text)
            Text(tomorrowDate, format: .dateTime.day().month(.twoDigits))
                .font(.system(size: 11))
                .foregroundStyle(palette.secondary)
            Rectangle()
                .fill(palette.separator)
                .frame(height: 0.5)
        }
        .frame(height: AgendaStyle.tomorrowHeaderHeight)
        .padding(.top, AgendaStyle.tomorrowHeaderGap)
    }

    private var tomorrowDate: Date {
        Calendar.current.date(byAdding: .day, value: 1, to: state.day) ?? state.day
    }
}

/// One row.
/// Tasks (reminders): due time on the left, a circle.
/// Events: a calendar icon, and start–end time (or "tutto il giorno") on the right.
struct AgendaRow: View {
    let item: AgendaItem
    /// Midnight of the day this row belongs to (today or tomorrow).
    let day: Date
    @Environment(\.colorScheme) var colorScheme
    private var palette: AgendaPalette { .of(colorScheme) }

    var body: some View {
        HStack(spacing: AgendaStyle.spacing) {
            timeLabel
                .frame(width: AgendaStyle.timeWidth, alignment: .leading)
            marker
                .frame(width: AgendaStyle.markerWidth, height: AgendaStyle.rowHeight)
            Text(item.title)
                .font(AgendaStyle.titleFont)
                .foregroundStyle(palette.text)
                .lineLimit(1)
            Spacer(minLength: 0)
            if item.kind == .event {
                eventTime
                    .foregroundStyle(palette.secondary)
                    .lineLimit(1)
                    .fixedSize()
            }
        }
        .frame(height: AgendaStyle.rowHeight)
    }

    // MARK: Events

    @ViewBuilder
    private var eventTime: some View {
        if let text = eventTimeText {
            Text(text)
                .font(AgendaStyle.timeFont)
        } else {
            Text("tutto il giorno")
                .font(.system(size: 12))
        }
    }

    /// "19:00–20:30", or "dalle 19:00" / "fino 20:30" for events running past
    /// midnight. Nil means all day.
    private var eventTimeText: String? {
        guard !item.isAllDay, let end = item.end else { return nil }
        let nextDay = Calendar.current.date(byAdding: .day, value: 1, to: day) ?? day.addingTimeInterval(86_400)
        let startsThisDay = item.start >= day
        let endsThisDay = end <= nextDay
        switch (startsThisDay, endsThisDay) {
        case (true, true): return "\(Self.time(item.start))–\(Self.time(end))"
        case (true, false): return "dalle \(Self.time(item.start))"
        case (false, true): return "fino \(Self.time(end))"
        case (false, false): return nil
        }
    }

    private static func time(_ date: Date) -> String {
        date.formatted(.dateTime.hour().minute())
    }

    // MARK: Tasks

    @ViewBuilder
    private var timeLabel: some View {
        if item.kind == .event {
            Color.clear
                .frame(height: 1)
        } else if item.start < day {
            Text(item.start, format: .dateTime.day().month(.twoDigits))
                .font(AgendaStyle.timeFont)
                .foregroundStyle(palette.red)
        } else if item.isAllDay {
            Color.clear
                .frame(height: 1)
        } else {
            Text(item.start, format: .dateTime.hour().minute())
                .font(AgendaStyle.timeFont)
                .foregroundStyle(item.isOverdue ? palette.red : palette.secondary)
        }
    }

    @ViewBuilder
    private var marker: some View {
        switch item.kind {
        case .event:
            Image(systemName: "calendar")
                .font(.system(size: 14, weight: .medium))
                .foregroundStyle(Color(hex: item.colorHex))
        case .reminder:
            // Just a marker: tapping anywhere on the card opens the Agenda app.
            Image(systemName: "circle")
                .font(.system(size: 15, weight: .medium))
                .foregroundStyle(Color(hex: item.colorHex))
        }
    }
}

/// Apple Calendar's red "current time" line.
struct NowLine: View {
    @Environment(\.colorScheme) var colorScheme

    var body: some View {
        let palette = AgendaPalette.of(colorScheme)
        HStack(spacing: 0) {
            Color.clear
                .frame(width: AgendaStyle.timeWidth + AgendaStyle.spacing + (AgendaStyle.markerWidth - 7) / 2, height: 1)
            Circle()
                .fill(palette.red)
                .frame(width: 7, height: 7)
            Rectangle()
                .fill(palette.red)
                .frame(height: 1)
        }
        .frame(height: AgendaStyle.nowLineHeight)
    }
}
