import AppIntents
import Foundation

/// Ticks off a reminder from the Lock Screen.
/// As a LiveActivityIntent, iOS runs it inside the app, not the widget extension.
struct CompleteReminderIntent: LiveActivityIntent {
    static let title: LocalizedStringResource = "Completa promemoria"
    static let isDiscoverable = false

    @Parameter(title: "Promemoria")
    var reminderID: String

    init() {}

    init(reminderID: String) {
        self.reminderID = reminderID
    }

    @MainActor
    func perform() async throws -> some IntentResult {
        #if !WIDGET_EXTENSION
        await AgendaController.shared.complete(reminderID: reminderID)
        #endif
        return .result()
    }
}
