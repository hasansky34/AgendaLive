import ActivityKit
import SwiftUI
import WidgetKit

@main
struct AgendaWidgetBundle: WidgetBundle {
    var body: some Widget {
        AgendaLiveActivity()
    }
}

struct AgendaLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: AgendaAttributes.self) { context in
            // Lock Screen and StandBy: follows the phone's light/dark mode
            LockScreenAgendaView(state: context.state.applyingStaleness(context.isStale))
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    HStack(spacing: 4) {
                        Image(systemName: "calendar")
                        Text("Oggi")
                    }
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(AgendaPalette.dark.red)
                    .padding(.leading, 6)
                    .environment(\.colorScheme, .dark)
                }
                DynamicIslandExpandedRegion(.trailing) {
                    Text(context.state.remainingLabel)
                        .font(.system(size: 13))
                        .foregroundStyle(AgendaPalette.dark.secondary)
                        .padding(.trailing, 6)
                        .environment(\.colorScheme, .dark)
                }
                DynamicIslandExpandedRegion(.bottom) {
                    VStack(spacing: 0) {
                        if context.state.islandRows.isEmpty {
                            Text("Nessun altro impegno oggi")
                                .font(.system(size: 14))
                                .foregroundStyle(AgendaPalette.dark.secondary)
                        } else {
                            ForEach(context.state.applyingStaleness(context.isStale).islandRows) { item in
                                AgendaRow(item: item, day: context.state.day)
                            }
                        }
                    }
                    .padding(.horizontal, 6)
                    .environment(\.colorScheme, .dark)
                }
            } compactLeading: {
                // iOS doesn't let a Live Activity opt out of the Dynamic Island,
                // so the compact and minimal views are left empty.
                EmptyView()
            } compactTrailing: {
                EmptyView()
            } minimal: {
                EmptyView()
            }
            .keylineTint(Color.clear)
        }
    }
}

/// The Lock Screen card, light or dark to match the phone.
struct LockScreenAgendaView: View {
    let state: AgendaAttributes.ContentState
    @Environment(\.colorScheme) var colorScheme

    var body: some View {
        let scheme: ColorScheme = state.dark.map { $0 ? ColorScheme.dark : ColorScheme.light } ?? colorScheme
        let palette = AgendaPalette.of(scheme)
        AgendaCardView(state: state)
            .environment(\.colorScheme, scheme)
            .padding(.horizontal, AgendaStyle.horizontalPadding)
            .padding(.vertical, AgendaStyle.verticalPadding)
            .activityBackgroundTint(palette.background.opacity(0.9))
            .activitySystemActionForegroundColor(palette.text)
    }
}
