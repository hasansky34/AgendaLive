import ActivityKit
import SwiftUI
import WidgetKit

@main
struct AgendaWidgetBundle: WidgetBundle {
    var body: some Widget {
        AgendaLiveActivity()
    }
}

struct AgendaLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: AgendaAttributes.self) { context in
            // Lock Screen and StandBy: follows the phone's light/dark mode
            LockScreenAgendaView(state: context.state)
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    HStack(spacing: 4) {
                        Image(systemName: "calendar")
                        Text("Oggi")
                    }
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(AgendaPalette.dark.red)
                    .padding(.leading, 6)
                    .environment(\.colorScheme, .dark)
                }
                DynamicIslandExpandedRegion(.trailing) {
                    Text(context.state.remainingLabel)
                        .font(.system(size: 13))
                        .foregroundStyle(AgendaPalette.dark.secondary)
                        .padding(.trailing, 6)
                        .environment(\.colorScheme, .dark)
                }
                DynamicIslandExpandedRegion(.bottom) {
                    VStack(spacing: 0) {
                        if context.state.islandRows.isEmpty {
                            Text("Nessun altro impegno oggi")
                                .font(.system(size: 14))
                                .foregroundStyle(AgendaPalette.dark.secondary)
                        } else {
                            ForEach(context.state.islandRows) { item in
                                AgendaRow(item: item, day: context.state.day)
                            }
                        }
                    }
                    .padding(.horizontal, 6)
                    .environment(\.colorScheme, .dark)
                }
            } compactLeading: {
                Image(systemName: "calendar")
                    .foregroundStyle(AgendaPalette.dark.red)
            } compactTrailing: {
                if let next = context.state.nextItem, !next.isAllDay {
                    Text(next.start, format: .dateTime.hour().minute())
                        .font(.system(size: 14).monospacedDigit())
                        .foregroundStyle(.white)
                } else {
                    Text("\(context.state.remainingToday)")
                        .font(.system(size: 14).monospacedDigit())
                        .foregroundStyle(AgendaPalette.dark.secondary)
                }
            } minimal: {
                Image(systemName: "calendar")
                    .foregroundStyle(AgendaPalette.dark.red)
            }
            .keylineTint(AgendaPalette.dark.red)
        }
    }
}

/// The Lock Screen card, light or dark to match the phone.
struct LockScreenAgendaView: View {
    let state: AgendaAttributes.ContentState
    @Environment(\.colorScheme) var colorScheme

    var body: some View {
        let palette = AgendaPalette.of(colorScheme)
        AgendaCardView(state: state)
            .padding(.horizontal, AgendaStyle.horizontalPadding)
            .padding(.vertical, AgendaStyle.verticalPadding)
            .activityBackgroundTint(palette.background.opacity(0.9))
            .activitySystemActionForegroundColor(palette.text)
    }
}
