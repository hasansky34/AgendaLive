# Agenda — today's events and reminders on the Lock Screen

A small personal iPhone app that keeps a Live Activity on your Lock Screen with
today's calendar events and Apple Reminders, in the Apple Calendar dark style.

- Overdue reminders show their time in red; a red line marks "now".
- Tasks (reminders) have a circle and their time on the left. Tap the circle on the Lock Screen to tick
  it off (repeating reminders move to the next date).
- Events have a calendar icon in the calendar's color and their start–end time on the right.
- Light and dark mode follow the iPhone's appearance setting (the Dynamic Island is always dark).
- Choose which calendars (Google ones included) and reminder lists appear: in the app, Opzioni › Calendari.
  This choice is separate from the Calendar app's own show/hide list.
- When today has room, the first items of tomorrow appear underneath.
- Requires iOS 18 or later and Xcode 16 or later.

## Install

1. Open `AgendaLive.xcodeproj` in Xcode.
2. Click the blue **AgendaLive** project at the top left. Under **Targets**, pick **AgendaLive**,
   open **Signing & Capabilities** and choose your **Team** (your Apple ID; add it under
   Xcode › Settings › Accounts if it isn't listed).
3. Do the same for the **AgendaLiveWidget** target. Both targets need the same team.
   The bundle IDs fill themselves in from your team, so you don't need to change them.
4. Connect your iPhone, select it as the run destination at the top, and press **Run** (⌘R).
   - If the iPhone asks, turn on Impostazioni › Privacy e sicurezza › Modalità sviluppatore and restart it.
   - With a free Apple ID, trust yourself once: Impostazioni › Generali › VPN e gestione dispositivi.
5. In the app, allow **full access** to Calendar and Reminders. The agenda appears on the Lock Screen.
6. When iOS asks "Vuoi continuare a consentire le attività in tempo reale da Agenda?", tap **Consenti sempre**.

## Install with appdb instead of Xcode

1. On the Mac, open Terminal, drag this folder onto it after typing `cd ` and press Return.
2. Run `bash make_ipa.sh`. After a minute or two it creates `AgendaLive.ipa` in this folder.
   The file is unsigned on purpose: appdb signs it for your device.
3. On appdb, open your device menu › **My apps (IPA files)** › **Upload IPA file(s)**, pick `AgendaLive.ipa`, then tap **Install**.
4. If you installed Agenda from Xcode before, delete that copy first.
5. Open Agenda once, allow full access to Calendar and Reminders, and continue with the automations below.

If the app opens but nothing appears on the Lock Screen, appdb's signing may have dropped the
Live Activity extension; installing from Xcode (above) avoids that.

## Keep it there all day

iOS ends any Live Activity after 8 hours, so set up three automations in the Shortcuts app (Comandi):

1. Automazione › **+** › **Ora del giorno** → 07:00, Ogni giorno, **Esegui immediatamente**.
2. Add the action **Mostra agenda sul blocco schermo** (app Agenda).
3. Repeat for 13:00 and 19:00.

Each run restarts the agenda and refreshes it. In between, the list also updates when you open the app,
when you tick a reminder off, and whenever iOS gives the app background time (iOS decides how often).

## Good to know

- **Free Apple ID:** apps you install from Xcode stop opening after 7 days. Connect the iPhone and press Run again.
  A paid Apple Developer account ($99/year) removes this limit (1 year).
- **Size:** iOS caps the Lock Screen card at about 160 points, so it shows up to 4 rows.
  The header says how many items are left today.
- **Dynamic Island:** while the agenda is on, the island shows a small calendar icon and your next time.
- **Overdue from earlier days:** off by default; switch it on in the app under Opzioni.
- Only Apple Calendar and Apple Reminders are read. Tasks kept only in Todoist or Google Tasks won't appear.

## Files

- `App/` — the app: settings screen, calendar picker, EventKit reading (`AgendaBuilder`), Live Activity control (`AgendaController`), Shortcuts actions.
- `Shared/` — used by both targets: the data model, the card view, the "complete reminder" action.
- `Widget/` — the Live Activity (Lock Screen + Dynamic Island).
- `Config/` — Info.plist files.
