#!/bin/bash
# Builds an unsigned AgendaLive.ipa for sideloading services such as appdb,
# which sign the app themselves. Run on a Mac with Xcode:  bash make_ipa.sh
set -euo pipefail
cd "$(dirname "$0")"

rm -rf build Payload AgendaLive.ipa

xcodebuild \
  -project AgendaLive.xcodeproj \
  -target AgendaLive \
  -configuration Release \
  -sdk iphoneos \
  SYMROOT="$PWD/build" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  build

APP="build/Release-iphoneos/AgendaLive.app"
if [ ! -d "$APP/PlugIns/AgendaLiveWidget.appex" ]; then
  echo "The Live Activity extension is missing from the build." >&2
  exit 1
fi

mkdir Payload
cp -R "$APP" Payload/
zip -qry AgendaLive.ipa Payload
rm -rf Payload

echo
echo "Done: $PWD/AgendaLive.ipa"
